package com.MariusPaulikas.FirstProject.controllers;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HomeController {
	
	@RequestMapping("/")
	public String hello() {
		return "Hello Human!";
		
	}
	
	@RequestMapping("/{n}")
	public String welcomeStudent(@PathVariable("n") String Firstname) {
		return "Hello "+ Firstname + "!";
	}
	
	@RequestMapping("/{n}/{y}")
	public String testing(@PathVariable("n") String Firstname, @PathVariable("y") String Lastname) {
		return "My first name is " + Firstname + " and my last name is " + Lastname;
	}

}
